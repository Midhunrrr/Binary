<?php

error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
    

		<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Binary Service</title>
        <link rel="shortcut icon" href="assets/dist/img/favicon.png" type="image/x-icon">
        <script src="../ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
        <script>
            WebFont.load({
                google: {families: ['Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i']},
                active: function () {
                    sessionStorage.fonts = true;
                }
            });
        </script>
        <!-- START GLOBAL MANDATORY STYLE -->
        <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css">
        <!-- START PAGE LABEL PLUGINS --> 
        <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css">
        <!-- START THEME LAYOUT STYLE -->
        <link href="assets/dist/css/style.css" rel="stylesheet" type="text/css">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="hold-transition fixed sidebar-mini">
        <!-- Site wrapper -->
		
        <div class="wrapper">
		
            <?php include('user_header.php'); ?> 
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <div class="content">
                    <!-- Content Header (Page header) -->
                    <div class="content-header">
                     <?php /*   <div class="header-icon">
                            <i class="pe-7s-box1"></i>
                        </div><?php */ ?>
                        <div class="header-title">
                            <h1>Dashboard  </h1>
                         
                        </div> 
                         <h4 style="float:right;"> Welcome <?php echo $_SESSION['user_name']."("."$user_id".")"; ?> </h4>
                          
                    </div> <!-- /. Content Header (Page header) -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="col-sm-12">
                           <h3>Order Details</h3>
                            </div>
                            <br/>
                            <br/>
                        <div class="col-sm-3">
                          &nbsp;<a href="#">
                          <img src="images/icons/trolley.png" width="80" height="80" align="middle">
                          <?php
                          $query=mysqli_query($con,"SELECT * FROM tbl_binaryincome WHERE userid='$email'");
                          //echo "SELECT * FROM tbl_binaryincome WHERE userid='$email' ORDER BY id DESC LIMIT 1";
                          $rows=mysqli_fetch_assoc($query);
                          ?>
                          <sup style="font-size:16px;"> (Count:<?php echo $Binary=$rows['total_amount'];
                          
                                               $binaryincome=$rows['income'];
                          
                          ?>)</sup>
                          <br/>
                         <span><b>Delivered Details&nbsp;&nbsp;</b></span></a>
                          
                          
                      </div>   
                            
                          <div class="col-sm-3">
                           &nbsp;&nbsp;<a href="referral_payout.php">
                           <img src="images/icons/hold.png" width="80" height="80" align="middle">
                            <?php
                          $queryr=mysqli_query($con,"SELECT SUM(total) AS total,SUM(income) AS referalincome FROM tbl_directincome WHERE myid='$user_id'");
                          //echo "SELECT * FROM tbl_binaryincome WHERE userid='$email' ORDER BY id DESC LIMIT 1";
                          $rowsr=mysqli_fetch_assoc($queryr);
                          ?>
                           <sup style="font-size:16px;"> (Count :<?php echo $Direct=$rowsr['total'];
                           
                           $refincome=$rowsr['referalincome'];
                           
                           ?> )</sup>
                           <br/>
                         
                         <span>
                         <b>Hold Details&nbsp;&nbsp;</b></span>
                          
                          </a>
                      </div>    
                      
                      
                            
                           <div class="col-sm-3">
                           &nbsp;&nbsp;<a href="#">
                           <img src="images/icons/clipboard.png" width="80" height="80" align="middle">
                            <?php
                          $slb=mysqli_query($con,"SELECT SUM(total) AS slbincome FROM tbl_slbincome WHERE userid='$email'");
                         // echo "SELECT SUM(total) AS slbincome FROM tbl_slbincome WHERE userid='$user_id'";
                          //echo "SELECT * FROM tbl_binaryincome WHERE userid='$email' ORDER BY id DESC LIMIT 1";
                          $slbr=mysqli_fetch_assoc($slb);
                          $slbr=$slbr['slbincome'];
                          ?>
                           <sup style="font-size:16px;"> (Count: <?php echo ($Binary+$Direct+$slbr); ?>  )</sup>
                           <br/>
                         <span><b>Total Orders&nbsp;&nbsp;</b></span>
                          </a>
                          
                      </div>
                      
                      
                       <div class="col-sm-3">
                           &nbsp;&nbsp;<a href="#">
                           <img src="images/icons/order.png" width="80" height="80" align="middle">
                            <?php
                          $slb=mysqli_query($con,"SELECT SUM(total) AS slbincome FROM tbl_slbincome WHERE userid='$email'");
                         // echo "SELECT SUM(total) AS slbincome FROM tbl_slbincome WHERE userid='$user_id'";
                          //echo "SELECT * FROM tbl_binaryincome WHERE userid='$email' ORDER BY id DESC LIMIT 1";
                          $slbr=mysqli_fetch_assoc($slb);
                          $slbr=$slbr['slbincome'];
                          ?>
                           <sup style="font-size:16px;"> (Count: <?php echo ($Binary+$Direct+$slbr); ?>  )</sup>
                           <br/>
                         <span><b>New Service Order&nbsp;&nbsp;</b></span>
                          </a>
                          
                      </div>
                           
                            
                      
                    
                            
                       
                      
                    
                      
                
                      
                     
                      
                      
                      
                
                      
                      
                
                      
                       </div>
                    </div>
                    
                </div> <!-- /.main content -->
            </div>
           <?php include('user_footer.php'); ?>
        </div> <!-- ./wrapper -->
		
        <!-- START CORE PLUGINS -->
        <script src="assets/plugins/jQuery/jquery-1.12.4.min.js"></script>
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <script src="assets/plugins/fastclick/fastclick.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/lobipanel/lobipanel.min.js"></script>
        <!-- DataTable Js -->
        <script src="assets/plugins/datatables/dataTables.min.js"></script>
        <script src="assets/plugins/datatables/dataTables-active.js"></script>
        <!-- START THEME LABEL SCRIPT -->
        <script src="assets/dist/js/theme.js"></script>
    </body>


</html>