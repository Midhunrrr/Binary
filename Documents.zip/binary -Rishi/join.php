
<!--/join user-->
<?php 
//functions
function pin_check($pin){
	global $con,$userid;
	$user_id = $_SESSION['user_id'];
	$query =mysqli_query($con,"select * from pin_list where pin='$pin' and userid='$user_id' and status='open'");
	if(mysqli_num_rows($query)>0){
		return true;
	}
	else{
		return false;
	}
}
function email_check($email){
	global $con;
	
	$query =mysqli_query($con,"select * from user where email='$email'"); //postedEmail
	if(mysqli_num_rows($query)>0){
		return false;
	}
	else{
		return true;
	}
}
function side_check($email,$side){
	global $con;
	$query =mysqli_query($con,"select * from tree where userid='$email'");
	$result = mysqli_fetch_array($query);
	$side_value = $result[$side];
	if($side_value==''){
		return true;
	}
	else{
		return false;
	}
}
function income($userid){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from income where userid='$userid'");
	$result = mysqli_fetch_array($query);
	$data['day_bal'] = $result['day_bal'];
	$data['current_bal'] = $result['current_bal'];
	$data['total_bal'] = $result['total_bal'];
	
	return $data;
}
function tree($userid){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from tree where userid='$userid'");
	$result = mysqli_fetch_array($query);
	$data['left'] = $result['left'];
	$data['right'] = $result['right'];
	$data['leftcount'] = $result['leftcount'];
	$data['rightcount'] = $result['rightcount'];
	
	return $data;
}
function getUnderId($userid){
	global $con;
	$query = mysqli_query($con,"select * from user where email='$userid'");
	$result = mysqli_fetch_array($query);
	return $result['under_userid'];
}
function getUnderIdPlace($userid){
	global $con;
	$query = mysqli_query($con,"select * from user where email='$userid'");
	$result = mysqli_fetch_array($query);
	return $result['side'];
}

?>

<!DOCTYPE html>
<html lang="en">
    

<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>VJP - Join User</title>
        <link rel="shortcut icon" href="assets/dist/img/favicon.png" type="image/x-icon">
        
		<script>
            WebFont.load({
                google: {families: ['Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i']},
                active: function () {
                    sessionStorage.fonts = true;
                }
            });
        </script>
        <!-- START GLOBAL MANDATORY STYLE -->
         <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css">
        <!-- START PAGE LABEL PLUGINS --> 

        <!-- START THEME LAYOUT STYLE -->
        <link href="assets/dist/css/style.css" rel="stylesheet" type="text/css"/>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="hold-transition fixed sidebar-mini">
        
        <!-- Preloader -->
        <div class="preloader"></div>
        
        <!-- Site wrapper -->
        <div class="wrapper">
            <?php include('user_header.php'); ?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Main content -->
                <div class="content">
                 <?php /* ?>   <div class="content-header">
                        <div class="header-icon">
                            <i class="pe-7s-note2"></i>
                        </div>
                        <div class="header-title"><br/>
                            <h1>Join</h1>
                            
                        </div>
                    </div> <?php */ ?>
                    <div class="row">
                        <!-- Form controls -->
                        <div class="col-sm-12">
                            <div class="panel panel-bd lobidrag">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <h4>Add Customer </h4>
                                    </div>
                                </div>
                                <div class="panel-body">
  
                                   <form name="form1" id="form1" method="post"> 
                                  
									<div class="row">
                                     
										
										
										
										  
										</div>
										<div class="col-md-4">
                                        <div class="form-group">
                                            <label>Customer Name <span style="color:red;">*</span></label>
												<input type="text" name="user" class="form-control" placeholder="Enter Name" required>
											
											 </div>
                                        </div>
										

                                        <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Email <span style="color:red;">*</span></label>
												<input type="email" name="email" id="email_id" class="form-control" onchange="check_email()"  placeholder="Enter Email" required>
											
											 </div>
                                        </div>
										
										<div class="col-md-4">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1"> Mobile <span style="color:red;">*</span></label>
												<input type="text" name="mobile" class="form-control" pattern="[0-9]{10}" maxlength="10" placeholder="Enter Mobile Numebr" required>
											 </div>
                                        </div>
									
                                        <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="prdName">Address</label>
											<input type="text" name="address"  class="form-control" placeholder="Enter Address" >
                                        </div>
                                        </div>
										<div class="col-md-4">
                                        <div class="form-group">
                                            <label for="DirectReff">City</label>
                                           <input type="text" name="account" class="form-control" placeholder="Enter Account" >	
                                        </div>
                                        </div>
									
										
                                     <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="DirectReff">Pincode</label>
                                           <input type="text" name="account" class="form-control" placeholder="Enter Account" >	
                                        </div>
                                        </div>
                                     
                                     
										 <div class="col-md-12">
											<div class="form-group">
												<button type="submit" name="join_user"  class="btn btn-base pull-right" Value="Join">Submit</button>
											</div>
										</div>
									</form>
                                </div>
                            </div>
                        </div>
                        <!-- Inline form -->
                        
                        <!-- Textual inputs -->
                        
                    </div>
                    <!-- Checkboxes & Radios -->
                    
                    
                </div>
            </div>
          <?php include('user_footer.php'); ?>
        </div> <!-- ./wrapper -->
        <!-- START CORE PLUGINS -->
        <script src="assets/plugins/jQuery/jquery-1.12.4.min.js"></script>
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <script src="assets/plugins/fastclick/fastclick.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/lobipanel/lobipanel.min.js"></script>
        <!-- START THEME LABEL SCRIPT -->
        <script src="assets/dist/js/theme.js"></script>
		
<script type="text/javascript">
function check_email(){
	var email=$("#email_id").val();
	$.ajax({
		type:'POST',
		data:{email:email},
		url:'check_email.php',
		success:function(data){
			if(data==1){
				alert("Email ID Already Exist..!");
				$("#email_id").val("");
			}
		}
	});
}
</script>
<script type="text/javascript">
function take_name(){
	var s_id=$("#sponser_id").val();
		$.ajax({
		type:'POST',
		data:{s_id:s_id},
		url:'take_name.php',
		success:function(data){
				$("#name_is").text(data);
		}
	});
}
</script>
<script type="text/javascript">
function check_pin(){
	var p_id=$("#pinid").val();
		$.ajax({
		type:'POST',
		data:{p_id:p_id},
		url:'check_pin.php',
		success:function(data){
				$("#package_is").text(data);
		}
	});
}
</script>
    </body>

<!-- Mirrored from adminpix.thememinister.com/forms_basic.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Jul 2018 07:10:45 GMT -->
</html>