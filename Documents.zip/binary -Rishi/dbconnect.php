<?php
error_reporting(0);
date_default_timezone_set('asia/kolkata');
$servername = "localhost";
$username = "root";
$password = "";
$dbname="binary_db";
$conn = mysqli_connect($servername, $username, $password, $dbname);
?>