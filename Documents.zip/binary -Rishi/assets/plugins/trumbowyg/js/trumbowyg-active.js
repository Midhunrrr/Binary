$(document).ready(function () {
    "use strict"; // Start of use strict
    //trumbowyg
    $('#trumbowyg').trumbowyg({
        svgPath: 'assets/plugins/trumbowyg/css/icons.svg'
    });
});