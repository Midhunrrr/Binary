<script>
   function numberonly(evt) {
       var iKeyCode = (evt.which) ? evt.which : evt.keyCode
       if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
           return false;

       return true;
   }    
</script>


<footer class="main-footer">
      <div class="pull-right hidden-xs">Binary Service</div>
      <strong>Copyright &copy; 2019</strong> All rights reserved. <i class="fa fa-heart color-green"></i>
</footer>