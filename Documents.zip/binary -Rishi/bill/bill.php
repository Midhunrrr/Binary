<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>bill</title>
<style>
.tab
{
	border-collapse:collapse
}
</style>
</head>
<body>
<b>Customer Details</b><br/>
<table width="100%" border="1" class="tab">
  <tr>
    <td width="17%">&nbsp;Customer Name</td>
    <td width="34%">&nbsp;Mr.</td>
    <td width="19%">&nbsp;Request No.</td>
    <td width="30%">&nbsp;MT I9</td>
  </tr>
  <tr>
    <td>&nbsp;Customer Address</td>
    <td>&nbsp;</td>
    <td>&nbsp;Request Date</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td rowspan="2">&nbsp;City </td>
    <td rowspan="2">&nbsp;</td>
    <td rowspan="2">&nbsp;Customer No.</td>
    <td> +91</td>
  </tr>
  <tr>
    <td>+91</td>
  </tr>
  <tr>
    <td>&nbsp;Pincode</td>
    <td>&nbsp;</td>
    <td>&nbsp;Customer Mail Id</td>
    <td>&nbsp;</td>
  </tr>
</table>
<br/>
Device &amp; Service Details<br/>
<table width="100%" border="1">
  <tr>
    <td width="16%">Device</td>
    <td width="26%" rowspan="3" valign="top">&#9632;<br/>
    &#9633;<br/>
    </td>
    <td width="15%">Manufacturer</td>
    <td width="43%">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>Model</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>IMEI / Serial No</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Defect Description</td>
    <td>&nbsp;</td>
    <td>Password</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>Accessories</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Service type</td>
    <td>&nbsp;</td>
    <td>Damage</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Inspection Charge</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;Estimated Cost</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;Final Cost</td>
    <td>&nbsp;</td>
    <td>&nbsp;Expected Delivery</td>
    <td>&nbsp;</td>
  </tr>
</table>
<br/>
<table width="100%" border="0">
  <tr>
    <td>&nbsp;*Terms & Conditions:<br/>
&nbsp;1.	In-warranty repair will be/ carried out subject to warranty validation by service centre staff.
<br/>
&nbsp;2.	Customer is required to carry valid warranty card/proof of purchase and it is to be produced at the time of submitting the product, else warranty service will not be provided.
<br/>
&nbsp;3.	The customer is requested to collect the product within one week from the date of receiving confirmation on the completion of the repair from the service centre. Electronic waste will not be given to the customer at any means. Prior information will be taken to the consideration.
<br/>
&nbsp;4.	To enquire the status of repair, customer should contact at number mentioned above with Request No. during working hours (10.30 AM to 06.30 PM). 
<br/>
&nbsp;5.	For billable devices, the repair will be carried out after necessary approval from the customer if estimate cost is higher than the specified.
<br/>
&nbsp;6.	The product has been accepted for service subject to internal verification. If product is found to be tampered, misused, components removed, cracked or liquid logged, the same will not be considered under warranty. In such case customer will have to pay for the repair services or the product will be returned without repairs and the customer has to pay the inspection charge. During Inspection and Service, damages / failures happening to the electronic device is common and Binary Service will not be responsible of any claims from customers on bill. In such case Binary Service decision is final.
<br/>
&nbsp;7.	Customer should remove SIM/Memory card before giving the device for service/repairs. Service centre will not be responsible of any claims from customers on bill from mobile service provider.
<br/>
&nbsp;8.	This receipt should be produced at the time of collecting the product. No deliveries will be made if this receipt is lost. In the event of loss of receipt, customer should submit request along with an indemnity letter with proof to the service centre to obtain the device.
<br/>
&nbsp;9.	The customer should himself ensure proper backup of all the data stored on the handset. The customer agrees that the service centre shall not be held responsible or liable for any data loss on the product in question.
<br/>
&nbsp;10.	The customer undertakes and agrees that the information provided by him/her is true and correct; Binary Service can use the same for the purpose of follow up and taking feedback on th¬¬e services by any means including voice, text, etc.

I have read and understood all the Terms & Conditions, and accept the same.	
</td>
  </tr>
</table>
<br/>
<table width="100%" border="1">
  <tr>
    <td width="71%">&nbsp;</td>
    <td width="29%">&nbsp;</td>
  </tr>
</table>

</body>
</html>