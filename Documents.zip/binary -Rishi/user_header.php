<header class="main-header"> 
                <a href="dashboard.php" class="logo"> <!-- Logo -->
                    <span class="logo-mini">
                        <!--<b>A</b>H-admin-->
                        User
                    </span>
                    <span class="logo-lg">
                        <!--<b>Admin</b>H-admin-->
                        BINARY SERVICE
                    </span>
                </a>
                <!-- Header Navbar -->
                <nav class="navbar navbar-static-top">
                    <a href="#" class="sidebar-toggle hidden-sm hidden-md hidden-lg" data-toggle="offcanvas" role="button"> <!-- Sidebar toggle button-->
                        <span class="sr-only">Toggle navigation</span>
                        <span class="ti-menu-alt"></span>
                    </a>
                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav"> 
                            <li class="dropdown dropdown-user">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="ti-user"></i></a>
                                <ul class="dropdown-menu">
                                   
                                    <li><a href="logout.php"><i class="ti-key"></i>Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- Tab panes -->
                <aside class="main-sidebar">
                    <!-- sidebar -->
                    <div class="sidebar">
                        <!-- sidebar menu -->
                        <ul class="sidebar-menu">
                           
							
							<li><a href="user_dashboard.php"><i class="ti-home"></i>Dashboard</a></li>
							
							 
                              <li class="treeview">
                                <a href="#">
                                    <i class="fa fa-users"></i><span>Customers</span>
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="add_customer.php">Add Customers</a></li> 
                                    <li><a href="view_customer.php">View Customers </a></li> 
                                  
                                    									
                                </ul>
                            </li>
                             
                             
                             <li class="treeview">
                                <a href="#">
                                    <i class="fa fa-users"></i><span>Service Orders</span>
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="#">Adding Service Order</a></li> 
                                    <li><a href="#">Total Order Reports </a></li> 
                                    <li><a href="#">Quick Search</a></li> 
                                    <li><a href="#">Export Orders </a></li> 
                                    									
                                </ul>
                            </li>

							
				
							
							 <li class="treeview">
                                <a href="#">
                                    <i class="fa fa-check-circle"></i><span>Log</span>
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="#">Log Report</a></li> 
									<!-- unUsed_pinList.php-->
									
                                    
                                </ul>
                            </li>
							
							 <li class="treeview">
                                <a href="#">
                                    <i class="fa fa-cogs"></i><span>Price Estimation</span>
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="myprofile.php">Price Estimation</a></li>                                    
                                    <li><a href="card.php">Price Estimation Report</a></li> 
                                    
                                </ul>
                            </li>
							
							
							
								<li class="treeview">
                                <a href="#">
                                    <i class="fa fa-cogs"></i><span>SMS</span>
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="#">Single SMS</a></li>                                    
                                    <li><a href="#">Mulitple SMS</a></li> 
                                    
                                </ul>
                            </li>	
                            
                            
                            
                            
								<li class="treeview">
                                <a href="#">
                                    <i class="fa fa-cogs"></i><span>System User</span>
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="#">Create User</a></li>                                    
                                    <li><a href="#">User Report</a></li> 
                                    
                                </ul>
                            </li>	
                            
                            
								<li class="treeview">
                                <a href="#">
                                    <i class="fa fa-cogs"></i><span>Product Master</span>
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="#">Create New</a></li>                                    
                                    <li><a href="#">Report</a></li> 
                                    
                                </ul>
                            </li>		 
							
                            
                            
								<li class="treeview">
                                <a href="#">
                                    <i class="fa fa-cogs"></i><span>Status Master</span>
                                    <span class="pull-right-container">
                                        <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="#">Create New</a></li>                                    
                                    <li><a href="#">User Report</a></li> 
                                    
                                </ul>
                            </li>	
							
							
						
							
                            <li><a href="#"><i class="fa fa-external-link"></i>Change Password</a></li>
							<li><a href="logout.php"><i class="fa fa-close"></i>Logout</a></li>
							
							
							
							

                          </div>
                            
                        </ul>
                    </div> <!-- /.sidebar -->
                </aside>
            </header>