<?php
@ob_start();
session_start();
include("dbconnect.php");
$adminname=$_POST['userid'];
$password=$_POST['password'];
$query="select * from tb_admin where user_id='$adminname' and password='$password'";
$result=mysqli_query($conn, $query); 
$row=mysqli_fetch_array($result);
$admin=$row['user_id'];
 if($admin!="") 
    {
  	$_SESSION['admin']=$adminname;
  	isset($_SESSION['admin']);
	header("location:user_dashboard.php");
	}
	else 
	{
	$_SESSION['notmessage']="Invalid Username or Password";
	header("location:index.php");
	}
?>

   