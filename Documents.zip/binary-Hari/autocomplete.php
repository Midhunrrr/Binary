<?php
error_reporting(0);

$servername = "localhost";
$username = "root";
$password = "";
$dbname="binary_db";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (isset($_GET['term'])){
	// $return_arr = array();
	   
	 $term = $_GET['term'];  
	    
	    $stmt = mysqli_query($conn,"SELECT * FROM customer_tbl WHERE cust_id LIKE '%$term%' or mobile LIKE '%$term%' or altmobile LIKE '%$term%'");
	   
	    
	    while($row = mysqli_fetch_array($stmt)) {	        
			$return_arr[] = $row['cust_name'];
			}
	/* Toss back results as json encoded array. */
    echo json_encode($return_arr);
}


?>