<?php
@ob_start();
error_reporting(0);
include "dbconnect.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Binary Service</title>
        <link rel="shortcut icon" href="assets/dist/img/favicon.png" type="image/x-icon">
        <script src="../ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
        
        <!-- START GLOBAL MANDATORY STYLE -->
        <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css">
        <!-- START PAGE LABEL PLUGINS --> 
        <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css">
        <!-- START THEME LAYOUT STYLE -->
        <link href="assets/dist/css/style.css" rel="stylesheet" type="text/css">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="hold-transition fixed sidebar-mini">        
        <!-- Preloader -->
        <div class="preloader"></div>        
        <!-- Site wrapper -->
        <div class="wrapper">
			<?php include('user_header.php'); ?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <div class="content">
                    <!-- Content Header (Page header) -->
                    <div class="content-header"></div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="panel panel-bd">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <h4>Quick Search</h4>										
                                    </div>
                                </div>
								<div class="panel-body">
									<div class="row">
										<div class="col-md-3">
											<div class="form-group">
												<label> Device </label>
												<select name="device" class="form-control" id="device">	
													<option value="">--Select Here--</option>
													<option value="Mobile/Tablet">Mobile/Tablet</option>
													<option value="Notebook">Notebook</option>
													<option value="Desktop/AlO">Desktop/AlO</option>
													<option value="Printer">Printer</option>
													<option value="Others">Others</option>
												</select>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label> Order ID <span style="color:red;">*</span></label>
												<input type="text" name="reqdt" placeholder="Order ID" class="form-control">
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label> Customer ID <span style="color:red;">*</span></label>
												<input type="text" name="reqdt" placeholder="Customer ID" class="form-control">
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label> Customer No <span style="color:red;">*</span></label>
												<input type="text" name="reqdt" placeholder="Customer No" class="form-control">
											</div>
										</div>
									</div>
								</div>
                                <div class="panel-body">									
                                    <div class="table-responsive">
                                        <table id="Example" class="table table-bordered table-striped table-hover">
                                            <thead>
												<tr>
													<th>S.No</th>
													<th>Req No</th>
													<th>Customer Name</th>
													<th>Date</th>
													<th>Device</th>
													<th>Defect Description</th>
													<th>status</th>													
													<th>Feedback</th>
													<!--<th>Edit</th>
													<th>Delete</th>-->
												</tr>
                                            </thead>
											<tbody>
												<?php 
													// $qry=mysqli_query($conn,"select * from customer_tbl order by cust_id desc");
													// $i=0;
													// while($row=mysqli_fetch_array($qry)){
														// $i++;
												?>
												<tr>
													<td><?php echo ""; ?></td>
													<td><?php echo "";  ?></td>
													<td><?php echo ""; ?></td>
													<td><?php echo ""; ?></td>
													<td><?php echo ""; ?></td>
													<td><?php echo ""; ?></td>
													<td><?php echo ""; ?></td>
													<td><?php echo ""; ?></td>
													<!--<td><center><a href="#"><i class="fa fa-pencil"></i></a></center></td></td>
													<td><center><a href="#" onclick='return confirm("Do you really want to Delete this Row");'><i class="fa fa-trash" style="color:red"></i></td>-->
												</tr>
												<?php //} ?>
											</tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>  
                </div> <!-- /.main content -->
            </div>
           <?php include('footer.php'); ?>
        </div> <!-- ./wrapper -->
        <!-- START CORE PLUGINS -->
        <script src="assets/plugins/jQuery/jquery-1.12.4.min.js"></script>
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <script src="assets/plugins/fastclick/fastclick.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/lobipanel/lobipanel.min.js"></script>
        <!-- DataTable Js -->
        <script src="assets/plugins/datatables/dataTables.min.js"></script>
        <script src="assets/plugins/datatables/dataTables-active.js"></script>
        <!-- START THEME LABEL SCRIPT -->
        <script src="assets/dist/js/theme.js"></script>
		<script>
			$(document).ready(function() {
				$('#Example').DataTable( {
				   
					
			} );	
			} );			
		</script>
    </body>
</html>