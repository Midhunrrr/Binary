<?php 
@ob_start();
error_reporting(0);
include "dbconnect.php";
$custid=$_GET['cust_id'];
$reqno=$_GET['reqno'];

$qry=mysqli_query($conn,"select * from order_tbl where reqno='$reqno'");
$data=mysqli_fetch_array($qry);

$query=mysqli_query($conn,"select * from customer_tbl where cust_id='$custid'");
$rows=mysqli_fetch_array($query);



if(isset($_POST['submit'])){

$cust_id=$_POST['cust_id'];
$cust_name=$_POST['cust_name'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$altmobile=$_POST['altmobile'];
$address=$_POST['address'];
$city=$_POST['city'];
$pincode=$_POST['pincode'];
$reqno=$_POST['reqno'];
$reqdt=$_POST['reqdt'];
$dtreason=$_POST['dtreason'];
$device=$_POST['device'];
$manf=$_POST['manf'];
$model=$_POST['model'];
$isno=$_POST['isno'];
$password=$_POST['password'];
$Battery=$_POST['Battery'];
$Adapter=$_POST['Adapter'];
$Back_cover=$_POST['Back_cover'];
$Others=$_POST['Others'];
$Billable=$_POST['Billable'];
$Warranty=$_POST['Warranty'];
$defdes=$_POST['defdes'];
$damage=$_POST['damage'];
$inscharge=$_POST['inscharge'];
$estcost=$_POST['estcost'];
$finalcost=$_POST['finalcost'];
$delivery=$_POST['delivery'];
$advamount=$_POST['advamount'];

	
// $qry=mysqli_query($conn,"insert into customer_tbl (cust_id,cust_name,mobile,altmobile,email,address,city,pincode,c_date) values ('$cust_id','$cust_name','$mobile','$altmobile','$email','$address','$city','$pincode',NOW())")or die();

	
// $query=mysqli_query($conn,"insert into order_tbl (cust_id,cust_name,mobile,altmobile,email,reqno,reqdt,dtreason,device,manuf,model,IMEI,password,battery,adapter,backcover,
// others,billable,warranty,defdes,damage,inscharge,esticost,finalcost,expdel,advamount,orddt) values ('$cust_id','$cust_name','$mobile','$altmobile','$email','$reqno','$reqdt','$dtreason',
// '$device','$manf','$model','$isno','$password','$Battery','$Adapter','$Back_cover','$Others','$Billable','$Warranty',
// '$defdes','$damage','$inscharge','$estcost','$finalcost','$delivery','$advamount',NOW())")or die();	

// echo "<script>alert('Successfully Added');window.location.href='total_order.php';</script>"; 
	
}


?>
<!DOCTYPE html>
<html lang="en">
	<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Binary Service</title>
        <link rel="shortcut icon" href="assets/dist/img/favicon.png" type="image/x-icon">
        <!-- START GLOBAL MANDATORY STYLE -->
        <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css">
        <!-- START PAGE LABEL PLUGINS --> 
		<!-- START THEME LAYOUT STYLE -->
        <link href="assets/dist/css/style.css" rel="stylesheet" type="text/css"/>
		
		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
<style>
/* The container */
.container {
  display: block;
  position: relative;
  padding-left: 30px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 12px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.container input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 17px;
  width: 17px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.container input:checked ~ .checkmark {
  background-color: #10585f;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.container .checkmark:after {
  left: 5px;
  top: 2px;
  width: 6px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
</style>

    </head>
    <body class="hold-transition fixed sidebar-mini">
        <!-- Preloader -->
        <div class="preloader"></div>
		<!-- Site wrapper -->
		<div class="wrapper">
			<?php include('user_header.php'); ?>
			<!-- Content Wrapper. Contains page content -->
			<div class="content-wrapper">
				<!-- Main content -->
				<div class="content">
					<div class="row">
						<!-- Form controls -->
						<div class="col-sm-12">
							<div class="panel panel-bd">
								<div class="panel-heading">
									<div class="panel-title">
										<h4>Add Service Order</h4>										
										<a href="total_order.php"><button type="button" class="btn btn-base pull-right">
										<i class="fa fa-eye"></i> View Order Report </button></a>									
									</div>
								</div>																
								<div class="panel-body">								
									<form name="form1" action="" autocomplete="off" id="form1" method="post"> 
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label>Customer ID <span style="color:red;">*</span></label>
													<input type="text" name="cust_id" id="cust_id" class="form-control" readonly value="<?php echo $rows['cust_id'];?>">
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label>Customer Name <span style="color:red;">*</span></label>
													<input type="text" name="cust_name" id="cust_name" value="<?php echo $rows['cust_name'];?>" class="form-control auto" placeholder="Enter Name" required>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label> Email <span style="color:red;">*</span></label>
													<input type="email" name="email" id="email_id" class="form-control" value="<?php echo $rows['email'];?>"  placeholder="Enter Email" required>
												</div>
											</div>
										</div>
										<div class="row">										
											<div class="col-md-4">
												<div class="form-group">
													<label for="exampleInputEmail1"> Mobile <span style="color:red;">*</span></label>
													<input type="text" name="mobile" id="mobile" value="<?php echo $rows['mobile'];?>" class="form-control" pattern="[0-9]{10}" maxlength="10" placeholder="Enter Mobile Number" required>
												</div>
											</div>
																				
											<div class="col-md-4">
												<div class="form-group">
													<label for="exampleInputEmail1">Alternate Mobile</label>
													<input type="text" name="altmobile" id="altmobile" value="<?php echo $rows['altmobile'];?>" class="form-control" pattern="[0-9]{10}" maxlength="10" placeholder="Enter Mobile Number" required>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label>Address</label>
													<textarea type="text" rows="3" id="address" style="resize:none;" name="address"  class="form-control" ><?php echo $rows['address'];?></textarea>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label>City</label>
													<input type="text" name="city" id="city" class="form-control" value="<?php echo $rows['city'];?>" placeholder="Enter City" >	
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label>Pincode</label>
													<input type="text" name="pincode" id="pincode" class="form-control" value="<?php echo $rows['pincode'];?>" placeholder="Enter Pincode" >	
												</div>
											</div>
										</div>
										<hr/ style="border-color:#ddd;">
										<div class="row">											
											<div class="col-md-4">
												<div class="form-group">
													<label>Request No</label>
													<input type="text" name="reqno" value="<?php echo $data['reqno'];?>" id="reqno" class="form-control" readonly>	
												</div>
											</div>											
											<div class="col-md-4 dt">
												<div class="form-group">
													<label>Request Date</label>
													<input type="text" name="reqdt" id="reqdt" value="<?php echo $data['reqdt'];?>" class="form-control" readonly >
													<!--<input type="text" name="reqdt" id="datepicker" value="<?php echo date('d/m/Y'); ?>" class="form-control">-->													
												</div>
											</div>
											<div class="col-md-4 dt" id="reason">
												<div class="form-group">
													<label>Reason</label>
													<textarea type="text" rows="4"  style="resize:none;" name="dtreason"  class="form-control" ><?php echo $data['dtreason'];?></textarea>	
												</div>
											</div>
										</div>
										<div class="row">										
											<div class="col-md-4">
												<div class="form-group">
													<label>Device</label>
													<select name="device" class="form-control" id="device">
														<option selected="<?php echo $data['device']; ?>"><?php echo $data['device']; ?></option>
														<option value="">--Select Here--</option>
														<option value="Mobile/Tablet">Mobile/Tablet</option>
														<option value="Notebook">Notebook</option>
														<option value="Desktop/AlO">Desktop/AlO</option>
														<option value="Printer">Printer</option>
														<option value="Others">Others</option>
													</select>
												</div>
											</div>										
											<div class="col-md-4">
												<div class="form-group">
													<label>Manufacturer</label>
													<input type="text" name="manf" value="<?php echo $data['manuf'];?>" placeholder="Manufacturer" class="form-control">	
												</div>
											</div>											
											<div class="col-md-4">
												<div class="form-group">
													<label>Model</label>
													<input type="text" name="model" value="<?php echo $data['model'];?>" placeholder="Model" class="form-control">	
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label>IMEI / SerialNo.</label>
													<input type="text" name="isno" value="<?php echo $data['IMEI'];?>" placeholder="IMEI / SerialNo." class="form-control" required>	
												</div>
											</div>								
											<div class="col-md-4">
												<div class="form-group">
													<label>Password</label>
													<input type="text" name="password" value="<?php echo $data['password'];?>" placeholder="Password" class="form-control">
												</div>
											</div>
											<div class="col-md-2">
												<div class="form-group">
													<label>Accessories</label>
													<label class="container">Battery
													  <input name="Battery" type="checkbox" value="Battery" checked="<?php if($data['battery']=="Battery"){ echo "checked";}?>">
													  <span class="checkmark"></span>
													</label>
													<label  class="container">Adapter
													  <input type="checkbox" value="Adapter" name="Adapter" checked="<?php if($data['adapter']=="Adapter"){ echo "checked";}?>">
													  <span class="checkmark"></span>
													</label>
													<label class="container">Back cover
													  <input type="checkbox" value="Back cover" name="Back_cover" checked="<?php if($data['backcover']=="Back cover"){ echo "checked";}?>">
													  <span class="checkmark"></span>
													</label>
													<label class="container">Others
													  <input type="checkbox" value="Others" name="Others" checked="<?php if($data['others']=="Others"){ echo "checked";}else{}?>">
													  <span class="checkmark"></span>
													</label>	
												</div>
											</div>						
											<div class="col-md-2">
												<div class="form-group">
													<label>Service Type</label>
													<label class="container">Billable
													  <input type="checkbox" value="Billable" checked="checked" name="Billable">
													  <span class="checkmark"></span>
													</label>
													<label class="container">Warranty
													  <input type="checkbox" value="Warranty" name="Warranty">
													  <span class="checkmark"></span>
													  
													</label>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label>Defect Description</label>
													<textarea type="text" rows="4" style="resize:none;" name="defdes"  class="form-control" ></textarea>
												</div>
											</div>												
											<div class="col-md-4">
												<div class="form-group">
													<label>Damage (Visual Inspection)</label>
													<textarea type="text" rows="4" style="resize:none;" name="damage"  class="form-control" ></textarea>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label>Inspection Charge</label>
													<input type="text" name="inscharge" placeholder="Inspection Charge" class="form-control">
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label>Estimated Cost</label>
													<input type="text" name="estcost" placeholder="Estimated Cost" class="form-control">
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label>Final Cost<span style="color:red;">*</span></label>
													<input type="text" placeholder="Final Cost" name="finalcost" class="form-control">
												</div>
											</div>										
																					
											<div class="col-md-4">
												<div class="form-group">
													<label>Expected Delivery<span style="color:red;">*</span></label>
													<input type="text" placeholder="Expected Delivery" id="datepicker1" name="delivery" class="form-control">
												</div>
											</div>		
										</div>
										<div class="row">										
											<div class="col-md-4">
												<div class="form-group">
													<label>Advance Amount (If collected)</label>
													<input type="text" placeholder="Advance Amount" name="advamount" class="form-control">
												</div>
											</div>										
											<div class="col-md-4">
												<div class="form-group">
													<label>Assign To</label>
													<input list="assign_to" name="assign_to[]" id="assignto" class="form-control" placeholder="Assign To" required>
													<datalist  name="assign_to[]" id="assign_to">
														<option value="--Select Here--">													
													</datalist>
												</div>
											</div>	
										</div>
										<div class="col-md-12">
											<div class="box-footer pull-right">
												<button type="reset" class="btn btn-danger">Reset</button>
												<button type="submit" name="submit"  class="btn btn-base ">Submit</button>
											</div>
										</div>									
									</form>
								</div>
							</div>
						</div>
						<!-- Inline form -->
						<!-- Textual inputs -->
					</div>
					<!-- Checkboxes & Radios -->
				</div>
			</div>
			<?php include('user_footer.php'); ?>
		</div> <!-- ./wrapper -->
        <!-- START CORE PLUGINS -->
        <script src="assets/plugins/jQuery/jquery-1.12.4.min.js"></script>
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <script src="assets/plugins/fastclick/fastclick.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/lobipanel/lobipanel.min.js"></script>
        <!-- START THEME LABEL SCRIPT -->
        <script src="assets/dist/js/theme.js"></script>
 

<script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>	
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript">
$(function() {
	
	//autocomplete
	$(".auto").autocomplete({
		source: "autocomplete.php",
		
	});				

});
</script>
		<script>
			$(document).ready(function(){
				$(document).on('change','select[name="device"]',function(){
					var reqno = $(this).val();
					console.log(reqno);
					$.ajax({
						type:'POST',
						url:'requestno.php',
						data:{'reqno':reqno},
						dataType:'json',
						success:function(data)
						{
							$('#reqno').val(data);
							// console.log(data);
						}
					});
				});
			});
		</script>
		<script>
		$(document).ready(function(){
			$("#datepicker").hide();
			$("#reason").hide();
		  $(".dt").dblclick(function(){
			$("#datepicker").show();
			$("#reason").show();			
			$("#reqdt").hide();			
		  });
		});
		</script>
		<script>
		$(function() 
		{
		  $("#datepicker").datepicker({  dateFormat: "dd/mm/yy" });
		});
		</script>
		<script>
		$(function() 
		{
		  $("#datepicker1").datepicker({  dateFormat: "dd/mm/yy" });
		});
		</script>  
		<script type="text/javascript">
			function check_name(){
				var cust_name=$("#custname").val();
				if(cust_name != ''){
				$.ajax({
					type:'POST',
					data:{cust_name:cust_name},
					url:'check_email.php',
					dataType:'JSON',
					success:function(data){
						$.each(data,function(key,value){
						$("#cust_id").val(value.cust_id);							
						$("#cust_name").val(value.cust_name);							
						$("#mobile").val(value.mobile);	
						$("#altmobile").val(value.altmobile);		
						$("#email_id").val(value.email);		
						$("#city").val(value.city);		
						$("#pincode").val(value.pincode);		
						$("#address").val(value.address);		
						});						
					}
				});
				}								
			}
		</script>
		<script type="text/javascript">
			// function take_name(){
				// var s_id=$("#sponser_id").val();
					// $.ajax({
					// type:'POST',
					// data:{s_id:s_id},
					// url:'take_name.php',
					// success:function(data){
							// $("#name_is").text(data);
					// }
				// });
			// }
		</script>
		<script type="text/javascript">
		// function check_pin(){
			// var p_id=$("#pinid").val();
				// $.ajax({
				// type:'POST',
				// data:{p_id:p_id},
				// url:'check_pin.php',
				// success:function(data){
						// $("#package_is").text(data);
				// }
			// });
		// }
		</script>
    </body>
</html>