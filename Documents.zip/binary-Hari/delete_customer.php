<?php
include "dbconnect.php";
$cust_id = $_GET['cust_id'];
$sql = mysqli_query($conn,"delete from customer_tbl where cust_id='$cust_id'");
echo "<script>alert('Deleted!');window.location.href='view_customer.php';</script>";
?>