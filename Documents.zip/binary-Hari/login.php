<?php
@ob_start();
session_start();
include("dbconnect.php");
$adminname=$_POST['userid'];
$password=$_POST['password'];
$query="select * from admin_tbl where username='$adminname' and password='$password'";
$result=mysqli_query($conn, $query); 
$row=mysqli_fetch_array($result);
$admin=$row['username'];
 if($admin!="") 
    {
  	$_SESSION['admin']=$adminname;
  	isset($_SESSION['admin']);
	echo "<script>alert('Login Successful');window.location.href='user_dashboard.php'</script>";
	// header("location:dashboard.php");
	}
	else 
	{
	// $_SESSION['notmessage']="Invalid Username or Password";
	echo "<script>alert('Invalid Username or Password'); window.location.href='index.php'</script>";
	
	}
?>

   