<?php
include 'dbconnect.php';
session_start();

$reqno = $_POST['reqno'];


$sll = mysqli_query($conn,"select MAX(reqno) as max_page from order_tbl");
$rows = mysqli_fetch_assoc($sll);
$invno = $rows['max_page'];
$y = date('y');
$a = date('y',strtotime('+1 Years'));
		if($reqno=="Mobile/Tablet")
		{
		$sno = $rows['max_page'];
		$sno = substr($sno,3);
		$str = $sno + 1;
		if($str<=9)
		{
			$res = "000".$str;
		}
		else if($str<=99)
		{
			$res = "00".$str;
		}
		else if($str<=999)
		{
			$res = "0".$res;
		}
		else
		{
			$res = $res;
		}
			$result = "MT"."/".$res;
		}
		else
		{
		$sno = $rows['max_page'];
		$sno = substr($sno,3);
		$str = $sno + 1;
		if($str<=9)
		{
			$res = "000".$str;
		}
		else if($str<=99)
		{
			$res = "00".$str;
		}
		else if($str<=999)
		{
			$res = "0".$res;
		}
		else
		{
			$res = $res;
		}
			$result = "DL"."/".$res;	
		}
		
$data[] = $result;
echo json_encode($data);
?>
