<?php
include "dbconnect.php";

$cust_name=$_POST['cust_name'];
if($cust_name != ''){
$query=mysqli_query($conn,"SELECT * FROM customer_tbl WHERE cust_name='$cust_name'");

	while($row=mysqli_fetch_array($query)){
		$data[] = $row;
	}
}
echo json_encode($data);
?>
