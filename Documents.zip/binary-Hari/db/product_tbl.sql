-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2019 at 08:02 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `binary_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `product_tbl`
--

CREATE TABLE `product_tbl` (
  `id` int(20) NOT NULL,
  `p_id` varchar(255) NOT NULL,
  `p_category` varchar(255) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_scd` varchar(50) NOT NULL,
  `p_desc` text NOT NULL,
  `p_wrty` varchar(30) NOT NULL,
  `p_qty` varchar(30) NOT NULL,
  `p_price` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_tbl`
--

INSERT INTO `product_tbl` (`id`, `p_id`, `p_category`, `p_name`, `p_scd`, `p_desc`, `p_wrty`, `p_qty`, `p_price`) VALUES
(3, 'BIN/0001', '12', '12', '12', '12', '12', '12', '2'),
(4, 'BIN/0002', 'sony', '5', '2', '1', '1', '1', '1'),
(5, 'BIN/0003', 'a&#039;vignesh&quot;vignesh&#039;', '2', 'lap', '13', '1 year', '2', '2'),
(6, 'BIN/0004', 'a', '1', '2', '13af&#039;', '12', '10', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product_tbl`
--
ALTER TABLE `product_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product_tbl`
--
ALTER TABLE `product_tbl`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
