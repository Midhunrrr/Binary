-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2019 at 08:06 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `binary_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE IF NOT EXISTS `admin_tbl` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `customer_tbl`
--

CREATE TABLE IF NOT EXISTS `customer_tbl` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `cust_id` varchar(250) NOT NULL,
  `cust_name` varchar(250) NOT NULL,
  `mobile` varchar(250) NOT NULL,
  `altmobile` varchar(100) NOT NULL,
  `email` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  `pincode` varchar(250) NOT NULL,
  `c_date` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `customer_tbl`
--

INSERT INTO `customer_tbl` (`id`, `cust_id`, `cust_name`, `mobile`, `altmobile`, `email`, `address`, `city`, `pincode`, `c_date`) VALUES
(2, 'CUST/0001', 'Hari', '8956231544', '8956239944', 'hari@gmail.com', 'testing', 'coimbatore', '641008', '2019-06-22 13:56:22'),
(3, 'CUST/0002', 'Krish', '8945784578', '8988231544', 'krish@gmail.com', 'test', 'Erode', '674102', '2019-06-22 14:08:28'),
(4, 'CUST/0003', 'test', '8787989898', '7634345454', 'test@gmail.com', 'test', 'Tirupur', '651005', '2019-06-26 10:14:26'),
(5, 'CUST/0004', 'testing', '8596478596', '8787848596', 'testing@gmail.com', 'testing', 'coimbatore', '641008', '2019-06-26 13:51:57');

-- --------------------------------------------------------

--
-- Table structure for table `employee_tbl`
--

CREATE TABLE IF NOT EXISTS `employee_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(50) NOT NULL,
  `emp_name` varchar(255) NOT NULL,
  `emp_type` varchar(255) NOT NULL,
  `emp_uname` varchar(255) NOT NULL,
  `emp_mbl` varchar(20) NOT NULL,
  `emp_mbl1` varchar(20) NOT NULL,
  `emp_mail` varchar(255) NOT NULL,
  `emp_add` text NOT NULL,
  `emp_city` varchar(255) NOT NULL,
  `emp_pin` varchar(10) NOT NULL,
  `emp_pwd` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `employee_tbl`
--

INSERT INTO `employee_tbl` (`id`, `emp_id`, `emp_name`, `emp_type`, `emp_uname`, `emp_mbl`, `emp_mbl1`, `emp_mail`, `emp_add`, `emp_city`, `emp_pin`, `emp_pwd`) VALUES
(2, '', 'vigneshr', 'Receptionist', 'viky543', '7373755024', '7373755023', 'vigneshppit@gmail.com', 'cbe address t', 'cbe1', '641002', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `order_tbl`
--

CREATE TABLE IF NOT EXISTS `order_tbl` (
  `id` int(250) NOT NULL AUTO_INCREMENT,
  `cust_id` varchar(250) NOT NULL,
  `cust_name` varchar(250) NOT NULL,
  `mobile` varchar(250) NOT NULL,
  `altmobile` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `reqno` varchar(250) NOT NULL,
  `reqdt` varchar(250) NOT NULL,
  `dtreason` text NOT NULL,
  `device` varchar(250) NOT NULL,
  `manuf` varchar(250) NOT NULL,
  `model` varchar(250) NOT NULL,
  `IMEI` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `battery` varchar(250) NOT NULL,
  `adapter` varchar(250) NOT NULL,
  `backcover` varchar(250) NOT NULL,
  `others` varchar(250) NOT NULL,
  `billable` varchar(250) NOT NULL,
  `warranty` varchar(250) NOT NULL,
  `defdes` text NOT NULL,
  `damage` text NOT NULL,
  `inscharge` varchar(250) NOT NULL,
  `esticost` varchar(250) NOT NULL,
  `finalcost` varchar(250) NOT NULL,
  `expdel` varchar(250) NOT NULL,
  `advamount` varchar(250) NOT NULL,
  `status` varchar(200) NOT NULL,
  `feedback` text NOT NULL,
  `orddt` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `order_tbl`
--

INSERT INTO `order_tbl` (`id`, `cust_id`, `cust_name`, `mobile`, `altmobile`, `email`, `reqno`, `reqdt`, `dtreason`, `device`, `manuf`, `model`, `IMEI`, `password`, `battery`, `adapter`, `backcover`, `others`, `billable`, `warranty`, `defdes`, `damage`, `inscharge`, `esticost`, `finalcost`, `expdel`, `advamount`, `status`, `feedback`, `orddt`) VALUES
(1, 'CUST/0004', 'testing', '8596478596', '8787848596', 'testing@gmail.com', 'MT/0001', '26-06-2019', '', 'Mobile/Tablet', 'Motorola', 'One power', '454152MEI25255', '1234', 'Battery', 'Adapter', 'Back cover', '', '', 'Warranty', 'test', 'test', '100', '500', '700', '30/06/2019', '100', 'Hold', '', '2019-06-26 13:51:57');

-- --------------------------------------------------------

--
-- Table structure for table `product_tbl`
--

CREATE TABLE IF NOT EXISTS `product_tbl` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `p_id` varchar(255) NOT NULL,
  `p_category` varchar(255) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_scd` varchar(50) NOT NULL,
  `p_desc` text NOT NULL,
  `p_wrty` varchar(30) NOT NULL,
  `p_qty` varchar(30) NOT NULL,
  `p_price` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `product_tbl`
--

INSERT INTO `product_tbl` (`id`, `p_id`, `p_category`, `p_name`, `p_scd`, `p_desc`, `p_wrty`, `p_qty`, `p_price`) VALUES
(3, 'BIN/0001', '12', '12', '12', '12', '12', '12', '2'),
(4, 'BIN/0002', 'sony', '5', '2', '1', '1', '1', '1'),
(5, 'BIN/0003', 'a&#039;vignesh&quot;vignesh&#039;', '2', 'lap', '13', '1 year', '2', '2'),
(6, 'BIN/0004', 'a', '1', '2', '13af&#039;', '12', '10', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
