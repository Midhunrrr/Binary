<?php 
@ob_start();
error_reporting(0);
include "dbconnect.php";
$cust_id=$_GET['cust_id'];
$sql = mysqli_query($conn,"select * from customer_tbl where cust_id='$cust_id'");
$row = mysqli_fetch_assoc($sql);



if(isset($_POST['submit'])){

$cust_id=$_POST['cust_id'];
$cust_name=$_POST['cust_name'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$altmobile=$_POST['altmobile'];
$address=$_POST['address'];
$city=$_POST['city'];
$pincode=$_POST['pincode'];
// echo "update customer_tbl set cust_id='$cust_id',cust_name='$cust_name',mobile='$mobile',email='$email',address='$address',city='$city',pincode='$pincode' where cust_id='$cust_id'";die();	
$qry=mysqli_query($conn,"update customer_tbl set cust_id='$cust_id',cust_name='$cust_name',mobile='$mobile',altmobile='$altmobile',email='$email',address='$address',city='$city',pincode='$pincode' where cust_id='$cust_id'");

echo "<script>alert('Successfully Updated');window.location.href='view_customer.php';</script>"; 	
}


?>
<!DOCTYPE html>
<html lang="en">
	<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Binary Service</title>
        <link rel="shortcut icon" href="assets/dist/img/favicon.png" type="image/x-icon">
        <!-- START GLOBAL MANDATORY STYLE -->
        <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css">
        <!-- START PAGE LABEL PLUGINS --> 
		<!-- START THEME LAYOUT STYLE -->
        <link href="assets/dist/css/style.css" rel="stylesheet" type="text/css"/>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="hold-transition fixed sidebar-mini">
        <!-- Preloader -->
        <div class="preloader"></div>
		<!-- Site wrapper -->
		<div class="wrapper">
			<?php include('user_header.php'); ?>
			<!-- Content Wrapper. Contains page content -->
			<div class="content-wrapper">
				<!-- Main content -->
				<div class="content">
					<div class="row">
						<!-- Form controls -->
						<div class="col-sm-12">
							<div class="panel panel-bd">
								<div class="panel-heading">
									<div class="panel-title">
										<h4>Edit Customer </h4>
										<a href="view_customer.php"><button type="button" class="btn btn-base pull-right">
										<i class="fa fa-eye"></i> View Customer</button></a>
									</div>
								</div>
								<div class="panel-body">
									<form name="form1" action="" autocomplete="off" id="form1" method="post"> 
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label>Customer ID <span style="color:red;">*</span></label>
													<input type="text" name="cust_id" value="<?php echo $row['cust_id']; ?>" class="form-control" readonly value="<?php echo $result;?>">
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label>Customer Name <span style="color:red;">*</span></label>
													<input type="text" value="<?php echo $row['cust_name']; ?>" name="cust_name" class="form-control" placeholder="Enter Name" required>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label>Email <span style="color:red;">*</span></label>
													<input type="email" value="<?php echo $row['email']; ?>" name="email" id="email_id" class="form-control" onchange="check_email()"  placeholder="Enter Email" required>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label for="exampleInputEmail1"> Mobile <span style="color:red;">*</span></label>
													<input type="text" name="mobile" value="<?php echo $row['mobile']; ?>" class="form-control" pattern="[0-9]{10}" maxlength="10" placeholder="Enter Mobile Number" required>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label for="exampleInputEmail1"> Alternative Mobile </label>
													<input type="text" name="altmobile" value="<?php echo $row['altmobile']; ?>" class="form-control" pattern="[0-9]{10}" maxlength="10" placeholder="Enter Mobile Number" required>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label for="prdName">Address</label>
													<textarea type="text" rows="3" style="resize:none;" name="address"  class="form-control" ><?php echo $row['address']; ?></textarea>
												</div>
											</div>											
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label for="DirectReff">City</label>
													<input type="text" name="city" value="<?php echo $row['city']; ?>" class="form-control" placeholder="Enter City" >	
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label for="DirectReff">Pincode</label>
													<input type="text" name="pincode" value="<?php echo $row['pincode']; ?>" class="form-control" placeholder="Enter Pincode" >	
												</div>
											</div>
										</div>
											<div class="col-md-12">
												<div class="box-footer pull-right">
													<button type="reset" class="btn btn-danger">Reset</button>
													<button type="submit" name="submit"  class="btn btn-base ">Update</button>
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
						<!-- Inline form -->
						<!-- Textual inputs -->
					</div>
					<!-- Checkboxes & Radios -->
				</div>
			</div>
			<?php include('user_footer.php'); ?>
		</div> <!-- ./wrapper -->
        <!-- START CORE PLUGINS -->
        <script src="assets/plugins/jQuery/jquery-1.12.4.min.js"></script>
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <script src="assets/plugins/fastclick/fastclick.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/lobipanel/lobipanel.min.js"></script>
        <!-- START THEME LABEL SCRIPT -->
        <script src="assets/dist/js/theme.js"></script>
		
		<script type="text/javascript">
		function check_email(){
			var email=$("#email_id").val();
			$.ajax({
				type:'POST',
				data:{email:email},
				url:'check_email.php',
				success:function(data){
					if(data==1){
						alert("Email ID Already Exist..!");
						$("#email_id").val("");
					}
				}
			});
		}
		</script>
		<script type="text/javascript">
		function take_name(){
			var s_id=$("#sponser_id").val();
				$.ajax({
				type:'POST',
				data:{s_id:s_id},
				url:'take_name.php',
				success:function(data){
						$("#name_is").text(data);
				}
			});
		}
		</script>
		<script type="text/javascript">
		function check_pin(){
			var p_id=$("#pinid").val();
				$.ajax({
				type:'POST',
				data:{p_id:p_id},
				url:'check_pin.php',
				success:function(data){
						$("#package_is").text(data);
				}
			});
		}
		</script>
    </body>
</html>