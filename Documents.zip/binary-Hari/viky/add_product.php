<?php
@ob_start();
include "dbconnect.php";

    $sql = mysqli_query($conn,"select MAX(p_id) as max_page from product_tbl");
    $row = mysqli_fetch_assoc($sql);
    $str = $row['max_page'];
    $se = substr($str,4);
    $s = $se+1;
if($s <= 9)
{
$r="000".$s;
}
else if($s <= 99)
{
$r="00".$s;
}

else if($s <= 999)
{
    $r="0".$s;  
}
else
{
$r=$s;  
}
$rt="BIN/".$r."";

if(isset($_POST['submit']))
{
$pcat = $_POST['pcat'];
$pname = $_POST['p_name'];
$pscd = $_POST['p_scd'];
$pdesc = $_POST['pdesc'];
$wrty = $_POST['p_wrty'];
$qty = $_POST['qty'];
$price = $_POST['price'];

$pdesc1 = htmlspecialchars($pdesc, ENT_QUOTES);


$sql = mysqli_query($conn,"INSERT INTO `product_tbl` (p_id,p_category,p_name,p_scd,p_desc,p_wrty,p_qty,p_price) values('$rt','$pcat','$pname','$pscd','$pdesc1','$wrty','$qty','$price')");
     header('location:view_product.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Binary Service</title>
        <link rel="shortcut icon" href="assets/dist/img/favicon.png" type="image/x-icon">
        
		<script>
            WebFont.load({
                google: {families: ['Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i']},
                active: function () {
                    sessionStorage.fonts = true;
                }
            });
        </script>
        <!-- START GLOBAL MANDATORY STYLE -->
         <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css">
        <!-- START PAGE LABEL PLUGINS --> 

        <!-- START THEME LAYOUT STYLE -->
        <link href="assets/dist/css/style.css" rel="stylesheet" type="text/css"/>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="hold-transition fixed sidebar-mini">
        
        <!-- Preloader -->
        <div class="preloader"></div>
        
        <!-- Site wrapper -->
        <div class="wrapper">
            <?php include('user_header.php'); ?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Main content -->
                <div class="content">
                    <div class="row">
                        <!-- Form controls -->
                        <div class="col-sm-12">
                            <div class="panel panel-bd">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <h4>Add Product</h4>
                                        <a href="view_product.php" class="btn btn-base pull-right" style="color:white;"><i class="fa fa-eye"></i>View Products</a>
                                    </div>
                                </div>
    <div class="panel-body">
        <form name="form1" id="form1" method="post" action=""> 
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Product Category <span style="color:red;">*</span></label>
            				<input type="text" name="pcat" class="form-control" placeholder="Product Category" required>
            		</div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Product Name<span style="color:red;">*</span></label>
            			    <input type="text" name="p_name" class="form-control" placeholder="Product Name" required>
            		</div>
                </div>
            	<div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Product ShortCode<span style="color:red;">*</span></label>
            				<input type="text" name="p_scd" class="form-control" placeholder="Product ShortCode" required>
            		</div>
                </div>
            </div>
            <div class="row">
            	<div class="col-md-4">
                    <div class="form-group">
                        <label for="prdName">Description</label>
            	       		<input type="text" name="pdesc"  class="form-control" placeholder="Description" >
                    </div>
                </div>
            	<div class="col-md-4">
                    <div class="form-group">
                        <label for="DirectReff">Warrenty</label>
                            <input type="text" name="p_wrty" class="form-control" placeholder="Warrenty" >
                    </div>
                </div>
            	<div class="col-md-4">
                    <div class="form-group">
                        <label for="DirectReff">Quantity</label>
                            <input type="text" name="qty" class="form-control" placeholder="Quantity" >	
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="DirectReff">Price</label>
                            <input type="text" name="price" class="form-control" placeholder="Price" >    
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    
                </div>

                <div class="col-md-3">
            	    <div class="form-group">
                        <input type="Reset"  class="btn btn-danger pull-right" value="Reset">
            		</div>
            	</div>
                <div class="col-md-3">
                    <div class="form-group">
                        <input type="submit" name="submit" class="btn btn-base" value="Submit">
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
                        </div>
                        <!-- Inline form -->
                        
                        <!-- Textual inputs -->
                        
                    </div>
                    <!-- Checkboxes & Radios -->
                    
                    
                </div>
            </div>
          <?php include('user_footer.php'); ?>
        </div> <!-- ./wrapper -->
        <!-- START CORE PLUGINS -->
        <script src="assets/plugins/jQuery/jquery-1.12.4.min.js"></script>
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <script src="assets/plugins/fastclick/fastclick.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/lobipanel/lobipanel.min.js"></script>
        <!-- START THEME LABEL SCRIPT -->
        <script src="assets/dist/js/theme.js"></script>
		
<script type="text/javascript">
function check_email(){
	var email=$("#email_id").val();
	$.ajax({
		type:'POST',
		data:{email:email},
		url:'check_email.php',
		success:function(data){
			if(data==1){
				alert("Email ID Already Exist..!");
				$("#email_id").val("");
			}
		}
	});
}
</script>
<script type="text/javascript">
function take_name(){
	var s_id=$("#sponser_id").val();
		$.ajax({
		type:'POST',
		data:{s_id:s_id},
		url:'take_name.php',
		success:function(data){
				$("#name_is").text(data);
		}
	});
}
</script>
<script type="text/javascript">
function check_pin(){
	var p_id=$("#pinid").val();
		$.ajax({
		type:'POST',
		data:{p_id:p_id},
		url:'check_pin.php',
		success:function(data){
				$("#package_is").text(data);
		}
	});
}
</script>
    </body>
</html>