<?php
@ob_start();
include "dbconnect.php";

    $sql = mysqli_query($conn,"select MAX(p_id) as max_page from employee_tbl");
    $row = mysqli_fetch_assoc($sql);
    $str = $row['max_page'];
    $se = substr($str,4);
    $s = $se+1;
if($s <= 9)
{
$r="000".$s;
}
else if($s <= 99)
{
$r="00".$s;
}

else if($s <= 999)
{
    $r="0".$s;  
}
else
{
$r=$s;  
}
$rt="EMP/".$r."";

if(isset($_POST['submit']))
{
$ename = $_POST['ename'];
$embl = $_POST['embl'];
$embl1 = $_POST['embl1'];
$email = $_POST['email'];
$address = $_POST['address'];
$city = $_POST['city'];
$pin = $_POST['pin'];
$uname = $_POST['uname'];
$utyp = $_POST['utyp'];
$pwd = $_POST['pwd'];
$sql = mysqli_query($conn,"INSERT INTO `employee_tbl` (emp_id,emp_name,emp_type,emp_uname,emp_mbl,emp_mbl1,emp_mail,emp_add,emp_city,emp_pin,emp_pwd) values('$rt','$ename','$utyp','$uname','$embl','$embl1','$email','$address','$city','$pin','$pwd')");
     header('location:view_employee.php');
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Binary Service</title>
        <link rel="shortcut icon" href="assets/dist/img/favicon.png" type="image/x-icon">
        
		<script>
            WebFont.load({
                google: {families: ['Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i']},
                active: function () {
                    sessionStorage.fonts = true;
                }
            });
        </script>
        <!-- START GLOBAL MANDATORY STYLE -->
         <link href="assets/dist/css/base.css" rel="stylesheet" type="text/css">
        <!-- START PAGE LABEL PLUGINS --> 

        <!-- START THEME LAYOUT STYLE -->
        <link href="assets/dist/css/style.css" rel="stylesheet" type="text/css"/>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="hold-transition fixed sidebar-mini">
        
        <!-- Preloader -->
        <div class="preloader"></div>
        
        <!-- Site wrapper -->
        <div class="wrapper">
            <?php include('user_header.php'); ?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Main content -->
                <div class="content">
                    <div class="row">
                        <!-- Form controls -->
                        <div class="col-sm-12">
                            <div class="panel panel-bd">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <h4>Add Employee</h4>
                                    </div>
                                </div>
                                <div class="panel-body">
  
                                   <form name="form1" id="form1" method="post"> 
                                    <div class="row">
                                        <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Employee code <span style="color:red;">*</span></label>
                                                <input type="text" name="ecode" class="form-control" value="<?php echo $rt; ?>" readonly>
                                            
                                             </div>
                                        </div>
                                        <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Employee Name<span style="color:red;">*</span></label>
                                                <input type="text" name="ename"  class="form-control"  placeholder="Enter Name" required>
                                            
                                             </div>
                                        </div>
                                        <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1"> Mobile <span style="color:red;">*</span></label>
                                                <input type="text" name="embl" class="form-control" pattern="[0-9]{10}" maxlength="10" placeholder="Enter Mobile Numebr" required>
                                             </div>
                                        </div>
                                    </div>
                                    <div class="row">
										<div class="col-md-4">
                                        <div class="form-group">
                                            <label>Alternate Mobile Number<span style="color:red;">*</span></label>
												<input type="text" name="embl1" class="form-control" pattern="[0-9]{10}" maxlength="10" placeholder="Enter Mobile Numebr" required>
											</div>
                                        </div>
										<div class="col-md-4">
                                        <div class="form-group">
                                            <label>Email <span style="color:red;">*</span></label>
												<input type="email" name="email" id="email_id" class="form-control" onchange="check_email()"  placeholder="Enter Email" required>
											
											 </div>
                                        </div>
                                        <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="prdName">Address</label>
                                            <input type="text" name="address"  class="form-control" placeholder="Enter Address" >
                                        </div>
                                        </div>
									</div>
                                    <div class="row">
                                       <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="DirectReff">City</label>
                                           <input type="text" name="city" class="form-control" placeholder="Enter City" >	
                                        </div>
                                        </div>
									<div class="col-md-4">
                                        <div class="form-group">
                                            <label for="DirectReff">Pincode</label>
                                           <input type="text" name="pin" class="form-control" placeholder="Enter Pincode" >	
                                        </div>
                                        </div>
                                        <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="prdName">User Name</label>
                                            <input type="text" name="uname"  class="form-control" placeholder="User Name" >
                                        </div>
                                        </div>
                                     
                                    </div>
                                    <div class="row">
                                        
                                        <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="DirectReff">User Type</label> 
                                            <select name="utyp" class="form-control">
                                                <option value="">Select Here</option>
                                                <option value="Receptionist">Receptionist</option>
                                                <option value="Service_Engineer">Service Engineer</option>
                                            </select>
                                        </div>
                                        </div>
                                    
                                        
                                     <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="DirectReff">Password</label>
                                           <input type="text" name="pwd" class="form-control" placeholder="Password" > 
                                        </div>
                                        </div>
                                     
                                    </div>
                                <div class="row">
                                        <div class="col-md-6"></div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                            <input type="Reset"  class="btn btn-danger pull-right" value="Reset">
                                            </div>
                                        </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <input type="submit" name="submit" class="btn btn-base" value="Submit">
                                        </div>
                                    </div>
                                </div>
									</form>
                                </div>
                            </div>
                        </div>
                        <!-- Inline form -->
                        
                        <!-- Textual inputs -->
                        
                    </div>
                    <!-- Checkboxes & Radios -->
                    
                    
                </div>
            </div>
          <?php include('user_footer.php'); ?>
        </div> <!-- ./wrapper -->
        <!-- START CORE PLUGINS -->
        <script src="assets/plugins/jQuery/jquery-1.12.4.min.js"></script>
        <script src="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
        <script src="assets/plugins/fastclick/fastclick.min.js"></script>
        <script src="assets/plugins/metisMenu/metisMenu.min.js"></script>
        <script src="assets/plugins/lobipanel/lobipanel.min.js"></script>
        <!-- START THEME LABEL SCRIPT -->
        <script src="assets/dist/js/theme.js"></script>
		
<script type="text/javascript">
function check_email(){
	var email=$("#email_id").val();
	$.ajax({
		type:'POST',
		data:{email:email},
		url:'check_email.php',
		success:function(data){
			if(data==1){
				alert("Email ID Already Exist..!");
				$("#email_id").val("");
			}
		}
	});
}
</script>
<script type="text/javascript">
function take_name(){
	var s_id=$("#sponser_id").val();
		$.ajax({
		type:'POST',
		data:{s_id:s_id},
		url:'take_name.php',
		success:function(data){
				$("#name_is").text(data);
		}
	});
}
</script>
<script type="text/javascript">
function check_pin(){
	var p_id=$("#pinid").val();
		$.ajax({
		type:'POST',
		data:{p_id:p_id},
		url:'check_pin.php',
		success:function(data){
				$("#package_is").text(data);
		}
	});
}
</script>
    </body>
</html>